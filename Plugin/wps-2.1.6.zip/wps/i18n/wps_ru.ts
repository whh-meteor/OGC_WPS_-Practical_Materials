<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="2.0" language="ru" sourcelanguage="">
<context>
    <name>Bookmarks</name>
    <message>
        <location filename="Ui_qgswpsbookmarks.py" line="21"/>
        <source>WPS-Bookmarks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Ui_qgswpsbookmarks.py" line="30"/>
        <source>Service</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Ui_qgswpsbookmarks.py" line="31"/>
        <source>Identifier</source>
        <translation type="unfinished">Идентификатор</translation>
    </message>
    <message>
        <location filename="Ui_qgswpsbookmarks.py" line="32"/>
        <source>URL</source>
        <translation type="unfinished">URL</translation>
    </message>
    <message>
        <location filename="Ui_qgswpsbookmarks.py" line="40"/>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Ui_qgswpsbookmarks.py" line="44"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Ui_qgswpsbookmarks.py" line="48"/>
        <source>Run</source>
        <translation type="unfinished">Запустить</translation>
    </message>
</context>
<context>
    <name>Dialog</name>
    <message>
        <location filename="Ui_qgswpserrorgui.py" line="33"/>
        <source>Dialog</source>
        <translation>Диалог</translation>
    </message>
</context>
<context>
    <name>DlgAbout</name>
    <message>
        <location filename="doAbout.py" line="41"/>
        <source>Version: %1</source>
        <translation>Версия: %1</translation>
    </message>
    <message>
        <location filename="doAbout.py" line="42"/>
        <source>Date: %1</source>
        <translation>Дата: %1</translation>
    </message>
</context>
<context>
    <name>QgsNewHttpConnectionBase</name>
    <message>
        <location filename="Ui_qgsnewhttpconnectionbase.py" line="55"/>
        <source>Create a new WPS connection</source>
        <translation>Создать новое соединение с WPS сервером</translation>
    </message>
    <message>
        <location filename="Ui_qgsnewhttpconnectionbase.py" line="56"/>
        <source>Connection details</source>
        <translation>Параметры соединения</translation>
    </message>
    <message>
        <location filename="Ui_qgsnewhttpconnectionbase.py" line="57"/>
        <source>Name</source>
        <translation>Название</translation>
    </message>
    <message>
        <location filename="Ui_qgsnewhttpconnectionbase.py" line="58"/>
        <source>Name of the new connection</source>
        <translation>Название нового соединения</translation>
    </message>
    <message>
        <location filename="Ui_qgsnewhttpconnectionbase.py" line="59"/>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <location filename="Ui_qgsnewhttpconnectionbase.py" line="60"/>
        <source>HTTP address of the Web Map Server</source>
        <translation>HTTP адрес WPS сервера</translation>
    </message>
    <message>
        <location filename="ui_newhttpconnectionbase.py" line="67"/>
        <source>Version</source>
        <translation>Версия</translation>
    </message>
</context>
<context>
    <name>QgsWps</name>
    <message>
        <location filename="QgsWpsDockWidget.py" line="124"/>
        <source> upload data ...</source>
        <translation> загрузка данных на сервер ...</translation>
    </message>
    <message>
        <location filename="QgsWpsDockWidget.py" line="128"/>
        <source> is running ...</source>
        <translation> выполняется ...</translation>
    </message>
    <message>
        <location filename="QgsWpsDockWidget.py" line="132"/>
        <source> download data ...</source>
        <translation> получение данных ...</translation>
    </message>
    <message>
        <location filename="QgsWpsDockWidget.py" line="142"/>
        <source> terminated with errors!</source>
        <translation> завершился с ошибками!</translation>
    </message>
    <message>
        <location filename="QgsWpsDockWidget.py" line="384"/>
        <source>Process selected objects only</source>
        <translation>Обрабатывать только выбранные объекты</translation>
    </message>
    <message>
        <location filename="QgsWpsDockWidget.py" line="384"/>
        <source>Selected</source>
        <translation>Выбранные</translation>
    </message>
    <message>
        <location filename="QgsWpsDockWidget.py" line="532"/>
        <source>Error</source>
        <translation>Ошибка</translation>
    </message>
    <message>
        <location filename="QgsWpsDockWidget.py" line="532"/>
        <source>Please load or select a vector layer!</source>
        <translation>Пожалуйста загрузите или выберете векторный слой!</translation>
    </message>
    <message>
        <location filename="QgsWpsDockWidget.py" line="696"/>
        <source>Run</source>
        <translation>Запустить</translation>
    </message>
    <message>
        <location filename="QgsWpsDockWidget.py" line="701"/>
        <source>Back</source>
        <translation>Назад</translation>
    </message>
    <message>
        <location filename="QgsWpsDockWidget.py" line="769"/>
        <source>WPS Error: Unable to download the result of reference: </source>
        <translation>Ошибка WPS: Не удается загрузить результат:</translation>
    </message>
    <message>
        <location filename="QgsWpsDockWidget.py" line="807"/>
        <source>Result</source>
        <translation>Результат</translation>
    </message>
    <message>
        <location filename="QgsWpsDockWidget.py" line="812"/>
        <source>WPS Error: Missing reference or literal data in response</source>
        <translation>Ошибка WPS: В ответе сервера отсутсвуют данные или ссылка на них</translation>
    </message>
    <message>
        <location filename="QgsWpsDockWidget.py" line="894"/>
        <source>Process result (text/plain)</source>
        <translation>Результат обработки (text/plain)</translation>
    </message>
    <message>
        <location filename="QgsWpsDockWidget.py" line="910"/>
        <source>Process result (unsupported mime type)</source>
        <translation>Результат обработки (неподдерживаемый тип mime)</translation>
    </message>
    <message>
        <location filename="qgswpstools.py" line="95"/>
        <source>Web Connection Failed</source>
        <translation>Не удалось соединиться с сервером</translation>
    </message>
    <message>
        <location filename="qgswpstools.py" line="293"/>
        <source>Unable to create temporal file: </source>
        <translation>Не удалось создать временный файл</translation>
    </message>
    <message>
        <location filename="qgswpstools.py" line="293"/>
        <source> for base64 encoding</source>
        <translation> для base64 кодирования</translation>
    </message>
    <message>
        <location filename="qgswpstools.py" line="349"/>
        <source>File open problem</source>
        <translation>Проблема при открытии файла</translation>
    </message>
    <message>
        <location filename="Ui_qgswpsgui.py" line="23"/>
        <source>Note: this plugin not considered stable yet. Use it on your own risk</source>
        <translation>ВНИМАНИЕ: этот плагин наданный момент не является стабильным. Используйте его на свой ​​страх и риск</translation>
    </message>
    <message>
        <location filename="Ui_qgswpsgui.py" line="50"/>
        <source>Server Connections</source>
        <translation>Соединения с серверами</translation>
    </message>
    <message>
        <location filename="Ui_qgswpsgui.py" line="57"/>
        <source>&amp;New</source>
        <translation>&amp;Создать</translation>
    </message>
    <message>
        <location filename="Ui_qgswpsgui.py" line="62"/>
        <source>Edit</source>
        <translation>Изменить</translation>
    </message>
    <message>
        <location filename="Ui_qgswpsgui.py" line="69"/>
        <source>C&amp;onnect</source>
        <translation>&amp;Подключиться</translation>
    </message>
    <message>
        <location filename="Ui_qgswpsgui.py" line="77"/>
        <source>Delete</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <location filename="Ui_qgswpsgui.py" line="31"/>
        <source>about</source>
        <translation>О модуле</translation>
    </message>
    <message>
        <location filename="Ui_qgswpsgui.py" line="45"/>
        <source>Identifier</source>
        <translation>Идентификатор</translation>
    </message>
    <message>
        <location filename="Ui_qgswpsgui.py" line="46"/>
        <source>Title</source>
        <translation>Наименование</translation>
    </message>
    <message>
        <location filename="Ui_qgswpsgui.py" line="47"/>
        <source>Abstract</source>
        <translation>Описание</translation>
    </message>
    <message>
        <location filename="Ui_qgswpsgui.py" line="81"/>
        <source>Add default server</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Ui_qgswpsgui.py" line="85"/>
        <source>Bookmarks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="qgswpstools.py" line="193"/>
        <source>Only WPS Version 1.0.0 is supported</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="qgswpstools.py" line="454"/>
        <source>Maximum allowed Value is too large</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="QgsWpsDockWidget.py" line="136"/>
        <source> finished successfully</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="QgsWpsDockWidget.py" line="292"/>
        <source>The process &apos;%1&apos; does not seem to support GML for the parameter &apos;%2&apos;, which is required by the QGIS WPS client.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="QgsWpsDockWidget.py" line="706"/>
        <source>Add Bookmark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="QgsWpsDockWidget.py" line="731"/>
        <source>Bookmark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="QgsWpsDockWidget.py" line="731"/>
        <source>The creation bookmark was successful.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="QgsWpsDockWidget.py" line="913"/>
        <source>Result not loaded to the map</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="QgsWpsDockWidget.py" line="913"/>
        <source>It seems QGIS cannot load the result of the process. The result has a &apos;%1&apos; type and can be accessed at &apos;%2&apos;. 

You could ask the service provider to consider changing the default data type of the result.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QgsWpsDescribeProcessGUI</name>
    <message>
        <location filename="Ui_qgswpsdescribeprocessgui.py" line="22"/>
        <source>Describe Process</source>
        <translation>Описание процесса</translation>
    </message>
    <message>
        <location filename="ui_qgswpsdescribeprocess.py" line="22"/>
        <source>Dialog</source>
        <translation>Диалог</translation>
    </message>
</context>
<context>
    <name>QgsWpsDockWidget</name>
    <message>
        <location filename="Ui_QgsWpsDockWidget.py" line="68"/>
        <source>QGIS WPS-Client</source>
        <translation>QGIS WPS-Клиент</translation>
    </message>
    <message>
        <location filename="Ui_QgsWpsDockWidget.py" line="69"/>
        <source>connect</source>
        <translation>Подключиться</translation>
    </message>
    <message>
        <location filename="Ui_QgsWpsDockWidget.py" line="70"/>
        <source>kill process</source>
        <translation>Прервать процесс</translation>
    </message>
</context>
<context>
    <name>QgsWpsGui</name>
    <message>
        <location filename="qgswpsgui.py" line="145"/>
        <source>Connection Refused. Please check your Proxy-Settings</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dlgAbout</name>
    <message>
        <location filename="Ui_QgsWpsAbout.py" line="106"/>
        <source>About QgsWPS</source>
        <translation>О модуле QgsWPS</translation>
    </message>
    <message>
        <location filename="Ui_QgsWpsAbout.py" line="33"/>
        <source>Version:</source>
        <translation>Версия:</translation>
    </message>
    <message>
        <location filename="Ui_QgsWpsAbout.py" line="38"/>
        <source>Date:</source>
        <translation>Дата:</translation>
    </message>
    <message>
        <location filename="Ui_QgsWpsAbout.py" line="107"/>
        <source>Contributors</source>
        <translation>Участники</translation>
    </message>
    <message>
        <location filename="Ui_QgsWpsAbout.py" line="109"/>
        <source>License</source>
        <translation>Лицензия</translation>
    </message>
    <message>
        <location filename="Ui_QgsWpsAbout.py" line="108"/>
        <source>Sponsors</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
